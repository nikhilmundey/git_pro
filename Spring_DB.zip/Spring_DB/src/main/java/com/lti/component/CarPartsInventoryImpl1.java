package com.lti.component;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

@Component("cpi")
public class CarPartsInventoryImpl1 implements CarPartsInventory {

	public void addNewPart(CarPart carPart) {
		//jdbc code here to insert carpart data in the table

		try{
		Class.forName("oracle.jdbc.driver.OracleDriver");
		
		Connection con= DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","hr","hr");
		PreparedStatement st= con.prepareStatement("insert into car_part values (?,?,?,?,?)");
		
		st.setInt(1, carPart.getPartNo());
		st.setString(2, carPart.getPartName());
		st.setString(3, carPart.getCarModel());
		st.setInt(4, carPart.getQuantity());
		st.setDouble(5, carPart.getPrice());
	
		st.executeUpdate();
		
		con.close();
		
		}
		catch (Exception e){
			e.printStackTrace();		
		}
	}

	public List<CarPart> getAvailableParts() {
		
        List <CarPart> cl= new ArrayList<CarPart>();

		try {
			
			Class.forName("oracle.jdbc.driver.OracleDriver");
			
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","hr","hr");
			
			Statement stmt= con.createStatement();
			
			ResultSet rs = stmt.executeQuery("select * from car_part");
			while (rs.next())
            {
				CarPart cp= new CarPart();
                cp.setPartNo(rs.getInt(1));
                cp.setPartName(rs.getString(2));
                cp.setCarModel(rs.getString(3));
                cp.setQuantity(rs.getInt(4));
                cp.setPrice(rs.getInt(5));
                cl.add(cp);
            }
			
			
		}
		
		catch (Exception e){
			e.printStackTrace();
		}
		
		return cl;
	}
	
}
