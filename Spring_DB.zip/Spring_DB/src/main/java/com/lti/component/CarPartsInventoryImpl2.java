package com.lti.component;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component("cpi2")
public class CarPartsInventoryImpl2 implements CarPartsInventory {

	@Autowired
	private DataSource dataSource;
	
	public void addNewPart(CarPart carPart) {
Connection con=null;
PreparedStatement st= null;

		try{
		
		 con= dataSource.getConnection();     //loosely coupled
		 st= con.prepareStatement("insert into car_part values (?,?,?,?,?)");
		
		st.setInt(1, carPart.getPartNo());
		st.setString(2, carPart.getPartName());
		st.setString(3, carPart.getCarModel());
		st.setInt(4, carPart.getQuantity());
		st.setDouble(5, carPart.getPrice());
	
		st.executeUpdate();
		
		con.close();
		
		}
		catch (Exception e){
			e.printStackTrace();		
		}
	}

	public List<CarPart> getAvailableParts() {
		
        List <CarPart> cl= new ArrayList<CarPart>();
        Connection con=null;
        Statement st= null;
		try {
			
			
		 con=dataSource.getConnection();
			
			 st= con.createStatement();
			
			ResultSet rs = st.executeQuery("select * from car_part");
			while (rs.next())
            {
				CarPart cp= new CarPart();
                cp.setPartNo(rs.getInt(1));
                cp.setPartName(rs.getString(2));
                cp.setCarModel(rs.getString(3));
                cp.setQuantity(rs.getInt(4));
                cp.setPrice(rs.getInt(5));
                cl.add(cp);
            }
			
	
		}
		
		catch (Exception e){
			e.printStackTrace();
		}
		
		return cl;
	}
	
}
