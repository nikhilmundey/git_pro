import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.lti.component.CarPart;
import com.lti.component.CarPartsInventory;

public class CarTest {
	@Test
	public  void carTest() {

		ApplicationContext ctx= new ClassPathXmlApplicationContext("car-config.xml");
		CarPartsInventory cp= (CarPartsInventory) ctx.getBean("cpi2");
		
		//Entity/ model instances are not created using Spring;
		CarPart ct=new CarPart();
		ct.setCarModel("Ford Mustang");
		ct.setPartName("Tyres");
		ct.setPartNo(015110);
		ct.setQuantity(110);
		ct.setPrice(76300);
		cp.addNewPart(ct);
		
//		ApplicationContext ctx= new ClassPathXmlApplicationContext("car-config.xml");
//		CarPartsInventory cp= (CarPartsInventory) ctx.getBean("cpi2");
//		List<CarPart> cl= cp.getAvailableParts();
//		
//		for (CarPart c1 : cl) {
//			System.out.println(c1.getPartName());
//		}
		
		
		
		
		
	}

}
